gcc ex01.c -o ex01.exe
gcc ex02.c -o ex02.exe
gcc ex03.c -o ex03.exe

./ex01.exe
./ex02.exe
./ex03.exe

rm -if *.exe
